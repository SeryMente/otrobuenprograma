(function(){
  'use strict';

  var STORY=[
    {
      track:0,title:'Otro Buen Programa',label:'El nombre',art:'name',
      text:'Primero que nada, el nombre. La razón por la que le llamé Otro Buen Programa está en concordancia con lo que considero el principio espiritual que separa a los niños de los hombres, espiritualmente hablando: el principio de no especialismo, según el cual la forma no tiene significado. Simplemente es otro programa. No tiene por qué ser particularmente importante debido al hecho de ser un programa especial, ya que todos los programas lo son. Este simplemente es otro.'
    },
    {
      track:0,title:'De bueno a grande',label:'La medida de una obra',art:'bishop',
      text:'Ahora bien, es otro buen programa porque el programa de doce pasos, históricamente y sobre todo desde mi punto de vista nacional, es un programa bueno. Recuerdo la novela Los miserables: cuando Napoleón se encuentra con el obispo, cruzan palabras. Napoleón dice: «Veo a un buen hombre», y el obispo responde: «Y yo veo a un gran hombre». Después, Napoleón hizo obispo de la localidad al entonces sacerdote. Lo había identificado como un gran hombre por aquello que podía hacer.'
    },
    {
      track:0,title:'Una segunda opción seria',label:'El antecedente y la alternativa',art:'currents',
      text:'El programa de doce pasos es un instrumento que, junto con el psicoanálisis, cambió el rumbo de la civilización en el siglo pasado y sigue teniendo una importancia preponderante en la sociedad mexicana. Únicamente compitiendo con la hegemonía del prestigioso programa de doce pasos podemos dotar a la población de una alternativa sólida que supere lo tendencioso y la moda para convertirse en un elemento real de cambio.'
    },
    {
      track:0,title:'Cambiar la pregunta',label:'Del síntoma a la raíz',art:'roots',
      text:'La disfunción familiar, y no solamente el abuso de sustancias, es desde mi punto de vista el problema a resolver. La disfunción familiar es básicamente lo que sucede cuando a las personas —y me incluyo— no nos importa lo suficiente lo que pasa con los otros seres humanos con quienes cohabitamos y coexistimos. Si las personas nos importaran, no habría disfunción familiar.'
    },
    {
      track:0,title:'Quienes no fueron importantes',label:'El destino de una fractura',art:'house',
      text:'Esto ocasiona que muchas personas terminen en centros de rehabilitación; o, para ser más exactos respecto de su función, centros de tratamiento para la disfunción familiar. Allí van a parar personas que, de alguna manera, no fueron lo suficientemente importantes. Y a pocas personas les importan, porque si fuera de otro modo probablemente no estarían allí.'
    },
    {
      track:0,title:'Grabar como puedo',label:'La voz presente',art:'voice',
      text:'Esta es una manera preliminar de hablar de lo que después tendré que volver a grabar, cuando me encuentre mejor de salud, para que mi voz no se sienta tan enferma o disfuncional. No me gusta cómo suena. Pero al menos empiezo a practicar estas ideas. Hacerlo me hace sentir empoderado y motivado. Podría hacerlo todo el día, aunque tuviera que pagar por hacerlo. Veo claramente que voy a disponer de energía para llevarlo a cabo. Por ahora he cambiado de opinión: creo que sí lo voy a subir así.'
    },
    {
      track:0,title:'El lugar decisivo',label:'Las relaciones personales · audio disponible',art:'network',
      text:'El programa está basado en las observaciones personales que yo he realizado a lo largo de mi vida y que tienen por conclusión la noción de que es en las relaciones personales donde está el área de oportunidad más importante que las personas de mi país tenemos a la hora de tratar de resolver los problemas que nos plagan como individuos y como sociedad. He observado que en la sociedad existen por lo menos dos tipos de personas.'
    },
    {
      track:0,title:'Dos formas de estar',label:'Una distinción por desplegar · audio disponible',art:'minds',
      text:'De esto pienso hablar de manera suficiente y, si se puede, profunda, aunque hasta donde sea necesario. Conforme yo me desarrollé, pude toparme con un artefacto llamado teoría de la desintegración positiva, que supone una forma de entender el desarrollo de las personas alternativa a la típicamente concebida, que proviene casi siempre del pensamiento psicoanalítico.'
    },
    {
      track:-1,title:'Mansedumbre',label:'El principio rector',art:'meekness',
      text:'Por ahora quiero indicar que la mansedumbre debe ser uno de los principios fundamentales que guíen esta iniciativa. Comprender la coexistencia de estas dos formas de mentalidad puede darle a una persona lo necesario no solo para comprenderse a sí misma, sino también para comprender al otro distinto que tiene enfrente.'
    },
    {
      track:-1,title:'El juego del adversario',label:'La deriva peligrosa',art:'adversary',
      text:'Esa coexistencia debe entenderse desde la mansedumbre, porque es fácil caer en la culpabilización del otro, la cacería de brujas o la búsqueda de justicia. Como sociedad pasamos mucho tiempo jugando al adversario con el otro; podemos caer fácilmente en el hábito de decirnos cosas jugando a que agredimos.'
    },
    {
      track:-1,title:'Yo no te voy a agredir',label:'La raya',art:'boundary',
      text:'Al empezar a abordar estos temas, lo fundamental es fijar una raya con la agresión y decir: «Yo no te voy a agredir». En la medida en que juegue a agredirte o a abusar de ti, pierdo toda posibilidad de entablar una comunicación que sea, en alguna medida, productiva. No se puede enfatizar esto lo suficiente.'
    },
    {
      track:-1,title:'Salir a hablar',label:'La acción de hoy',art:'flyer',
      text:'Por eso lo grabo como puedo el día de hoy, aunque no me siento muy bien. Hoy voy a repartir volantes con un código QR hacia una página donde intentaré establecer comunicación con lo que me rodea, para ver si podemos empezar a hablar sobre el elefante en la habitación.'
    },
    {
      track:-1,title:'Lo que podríamos encontrar',label:'El comienzo',art:'constellation',
      text:'Estoy seguro de que, si lo logramos, no podremos sino encontrar un cúmulo de cosas valiosas que eventualmente no podremos sino agradecer.'
    }
  ];

  var TRACKS=[
    {label:'▶',src:'assets/audio/otro-buen-programa.opus.b64',name:'Las relaciones personales'}
  ];

  var mount=document.getElementById('inicio');
  if(!mount) return;

  function esc(s){return s.replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function words(text){return text.match(/\S+\s*/g)||[];}
  function fmt(sec){if(!Number.isFinite(sec)) return '0:00';var m=Math.floor(sec/60),s=Math.floor(sec%60);return m+':'+String(s).padStart(2,'0');}

  function art(type,title){
    var common='<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#2c59b8"/><stop offset="1" stop-color="#101d42"/></linearGradient><radialGradient id="a"><stop stop-color="#edb25d"/><stop offset="1" stop-color="#d35f50"/></radialGradient></defs><rect width="600" height="430" fill="url(#g)"/>';
    var s='';
    if(type==='name') s='<circle class="pulse" cx="300" cy="205" r="118" fill="none" stroke="#fff" opacity=".15"/><circle cx="300" cy="205" r="74" fill="#fff" opacity=".07"/><text x="300" y="198" text-anchor="middle" fill="#fff" font-family="Georgia" font-size="44">otro</text><text x="300" y="232" text-anchor="middle" fill="#b8caf7" font-family="monospace" font-size="13" letter-spacing="4">BUEN PROGRAMA</text>';
    if(type==='bishop') s='<circle cx="175" cy="165" r="62" fill="#e8a85e"/><path d="M102 344c8-92 35-136 73-136s66 44 74 136" fill="#fff" opacity=".88"/><circle cx="425" cy="165" r="62" fill="#9eb9ee"/><path d="M350 344c9-92 36-136 75-136s67 44 75 136" fill="#fff" opacity=".18"/><path class="draw" d="M238 177C284 139 329 139 372 177" fill="none" stroke="#fff" stroke-width="3" stroke-dasharray="150" stroke-dashoffset="150"/><text x="300" y="99" text-anchor="middle" fill="#fff" font-family="Georgia" font-size="22">bueno  →  grande</text>';
    if(type==='currents') s='<path d="M-10 118C155 50 219 181 358 126S516 61 620 103" fill="none" stroke="#fff" opacity=".18" stroke-width="52"/><path class="draw" d="M-10 294C153 363 215 221 362 284S515 360 620 306" fill="none" stroke="#efa85b" stroke-width="19" stroke-linecap="round" stroke-dasharray="760" stroke-dashoffset="760"/><circle class="float" cx="437" cy="275" r="20" fill="#fff"/>';
    if(type==='roots') s='<path d="M300 45v142M300 187c-63 19-110 4-168-36M300 187c63 19 110 4 168-36M300 187c-62 54-73 118-108 187M300 187c62 54 73 118 108 187M300 187v187" stroke="#fff" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M0 186h600" stroke="#e8a85e" stroke-width="2" stroke-dasharray="8 9"/><text x="24" y="166" fill="#fff" opacity=".7" font-family="monospace" font-size="13">SÍNTOMA</text><text x="24" y="214" fill="#e8a85e" font-family="monospace" font-size="13">RELACIONES</text>';
    if(type==='house') s='<path d="M125 201 300 65l175 136v154H125Z" fill="#fff" opacity=".12" stroke="#fff" stroke-width="4"/><path d="m310 83-39 110 44 38-40 124" fill="none" stroke="#e8a85e" stroke-width="9"/><circle cx="223" cy="259" r="30" fill="#fff"/><circle class="float" cx="421" cy="331" r="25" fill="#e8a85e"/>';
    if(type==='voice') s='<g fill="none" stroke-linecap="round"><path d="M30 220h50l18-77 31 149 36-205 33 261 37-188 38 103 33-40 34 18 35-111 31 196 40-148 30 67h114" stroke="#fff" stroke-width="7"/><path class="pulse" d="M30 220h540" stroke="#e8a85e" stroke-width="2"/></g>';
    if(type==='network'||type==='minds'||type==='constellation'){
      s='<g stroke="#a9c1f3" stroke-width="2" opacity=".7"><path d="M90 110 210 74l92 107 111-68 99 104-78 112-130-39-112 79L90 252Z"/><path d="m210 74-18 295m110-188 132 148M90 252l214 38m109-177 21 216"/></g><g fill="#fff"><circle cx="90" cy="110" r="11"/><circle cx="210" cy="74" r="16"/><circle cx="302" cy="181" r="22"/><circle cx="413" cy="113" r="12"/><circle cx="512" cy="217" r="17"/><circle cx="434" cy="329" r="12"/><circle cx="304" cy="290" r="15"/><circle cx="192" cy="369" r="10"/><circle cx="90" cy="252" r="14"/></g><circle class="pulse" cx="302" cy="181" r="46" fill="none" stroke="#e8a85e" stroke-width="3"/>';
      if(type==='minds') s+='<path d="M300 30v370" stroke="#fff" opacity=".15"/><text x="154" y="397" text-anchor="middle" fill="#fff" font-family="monospace" font-size="12">FORMA 1</text><text x="448" y="397" text-anchor="middle" fill="#fff" font-family="monospace" font-size="12">FORMA 2</text>';
    }
    if(type==='meekness') s='<circle cx="300" cy="214" r="128" fill="#fff" opacity=".06"/><path class="draw" d="M82 275c78-6 101-55 157-55 36 0 39 32 61 32s25-32 61-32c56 0 79 49 157 55" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-dasharray="520" stroke-dashoffset="520"/><circle cx="300" cy="252" r="13" fill="#e8a85e"/><text x="300" y="145" text-anchor="middle" fill="#fff" font-family="Georgia" font-size="38">mansedumbre</text>';
    if(type==='adversary') s='<g font-family="monospace" font-size="19" fill="#fff"><text x="58" y="92">CULPA</text><text x="393" y="117">CASTIGO</text><text x="69" y="344">ENEMIGO</text><text x="403" y="326">ATAQUE</text></g><circle cx="225" cy="220" r="46" fill="#fff"/><circle cx="375" cy="220" r="46" fill="#e8a85e"/><path d="m280 184 40 72m0-72-40 72" stroke="#d35f50" stroke-width="13"/>';
    if(type==='boundary') s='<g fill="#fff"><circle cx="149" cy="214" r="52"/><circle cx="451" cy="214" r="52"/></g><path class="draw" d="M36 214h528" stroke="#e8a85e" stroke-width="9" stroke-dasharray="528" stroke-dashoffset="528"/><text x="300" y="154" text-anchor="middle" fill="#fff" font-family="Georgia" font-size="28">yo no te voy a agredir</text>';
    if(type==='flyer') s='<rect x="116" y="61" width="220" height="306" rx="5" fill="#fff"/><rect x="143" y="91" width="165" height="14" fill="#203d91"/><rect x="143" y="125" width="122" height="8" fill="#c1cae0"/><rect x="143" y="147" width="145" height="8" fill="#c1cae0"/><g fill="#14244c"><rect x="184" y="207" width="30" height="30"/><rect x="244" y="207" width="30" height="30"/><rect x="184" y="267" width="30" height="30"/><rect x="224" y="247" width="20" height="20"/><rect x="254" y="277" width="20" height="20"/></g><rect x="366" y="115" width="122" height="238" rx="18" fill="#0c1734" stroke="#fff" stroke-width="5"/><rect x="382" y="144" width="90" height="166" fill="#e9effc"/><path class="pulse" d="M320 237h74" stroke="#e8a85e" stroke-width="4"/>';
    if(type==='constellation') s+='<path class="draw" d="M62 384C195 321 278 355 350 278s123-96 192-176" fill="none" stroke="#e8a85e" stroke-width="5" stroke-dasharray="620" stroke-dashoffset="620"/>';
    return '<span class="art-note">Ilustración editorial</span><svg viewBox="0 0 600 430" role="img" aria-label="'+esc(title)+'">'+common+s+'</svg><p class="art-title">'+esc(title)+'</p>';
  }

  mount.innerHTML=
    '<div class="story-intro">'+
      '<p class="story-kicker"><span class="live"></span> Otro Buen Programa · relato sonoro</p>'+
      '<h1>La historia comienza con una voz.</h1>'+
      '<p class="dek">Escucha el origen de una segunda opción seria. La transcripción, la línea y las imágenes avanzan juntas.</p>'+
      '<p class="hint">Pulsa reproducir · también puedes tocar cualquier palabra</p>'+
    '</div>'+
    '<div class="story-player" aria-label="Reproductor del relato">'+
      '<button class="story-play" type="button" aria-label="Reproducir"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4v16l13-8z"/></svg></button>'+
      '<div class="story-transport"><div class="story-player-line"><span class="story-now">El nombre y el problema</span><span class="story-time">0:00 / 0:00</span></div><div class="story-wave" role="slider" tabindex="0" aria-label="Posición del audio" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><canvas></canvas><i class="story-progress"></i></div></div>'+
      '<div class="story-tracks">'+TRACKS.map(function(t,i){return '<button class="story-track" type="button" data-track="'+i+'" aria-current="'+(i===0)+'" aria-label="Audio recibido">'+t.label+'</button>';}).join('')+'</div>'+
      '<p class="story-audio-note" role="status">Audio original recibido · volumen normalizado · transcripción revisada. La grabación disponible corresponde a «Las relaciones personales» y termina después de «pensamiento psicoanalítico».</p>'+
    '</div>'+
    '<div class="story-rail">'+STORY.map(function(s,i){
      return '<article class="story-stop" data-track="'+s.track+'" data-scene="'+i+'" tabindex="-1">'+
        '<div class="story-copy"><span class="story-label">'+esc(s.label)+'</span><h2>'+esc(s.title)+'</h2><p class="story-transcript">'+words(s.text).map(function(w,j){return '<button type="button" class="story-word" data-word="'+j+'">'+esc(w.trim())+'</button> ';}).join('')+'</p></div>'+
        '<span class="story-node">'+String(i+1).padStart(2,'0')+'</span>'+
        '<div class="story-art">'+art(s.art,s.title)+'</div>'+
      '</article>';
    }).join('')+'</div>'+
    '<div class="story-end"><p>Hablar sin agredir puede ser el comienzo de algo que después agradeceremos.</p><a href="#top">Continuar con el documento ↓</a></div>'+
    '<audio class="story-audio" preload="metadata"></audio>';

  var audio=mount.querySelector('.story-audio');
  var play=mount.querySelector('.story-play');
  var now=mount.querySelector('.story-now');
  var time=mount.querySelector('.story-time');
  var progress=mount.querySelector('.story-progress');
  var wave=mount.querySelector('.story-wave');
  var canvas=wave.querySelector('canvas');
  var stops=[].slice.call(mount.querySelectorAll('.story-stop'));
  var trackButtons=[].slice.call(mount.querySelectorAll('.story-track'));
  var currentTrack=0,durations=[119.304],autoFollow=true,userScrollAt=0,lastScene=-1,wordMap=[],audioBlobUrl='',hasExactTiming=false;

  function drawWave(samples){
    var dpr=Math.min(window.devicePixelRatio||1,2),r=canvas.getBoundingClientRect(),w=Math.max(1,Math.round(r.width*dpr)),h=Math.max(1,Math.round(r.height*dpr));
    canvas.width=w;canvas.height=h;var c=canvas.getContext('2d');c.clearRect(0,0,w,h);c.fillStyle='rgba(255,255,255,.2)';
    var bars=Math.max(36,Math.floor(w/(5*dpr))),gap=2*dpr,bw=Math.max(1,w/bars-gap);
    for(var i=0;i<bars;i++){var amp=samples&&samples.length?samples[Math.floor(i*samples.length/bars)]:.18+.52*Math.abs(Math.sin(i*.73)*Math.cos(i*.17));var bh=Math.max(2,amp*h*.88);c.fillRect(i*w/bars,(h-bh)/2,bw,bh);}
  }
  drawWave();
  window.addEventListener('resize',function(){drawWave();});

  function buildMap(){
    var scenes=STORY.map(function(s,i){return {scene:i,track:s.track,count:words(s.text).length};});
    wordMap=[[]];
    [0].forEach(function(t){
      var list=scenes.filter(function(s){return s.track===t;}),total=list.reduce(function(a,s){return a+s.count;},0),cursor=0,d=durations[t]||total*.42;
      list.forEach(function(s){var start=cursor/total*d,end=(cursor+s.count)/total*d;for(var j=0;j<s.count;j++){wordMap[t].push({scene:s.scene,word:j,start:start+(end-start)*j/s.count,end:start+(end-start)*(j+1)/s.count});}cursor+=s.count;});
    });
  }
  buildMap();

  function setTrack(i,autoplay){
    currentTrack=i;now.textContent=TRACKS[i].name;
    trackButtons.forEach(function(b,j){b.setAttribute('aria-current',String(j===i));});
    clearWords();progress.style.width='0%';time.textContent='0:00 / '+fmt(durations[i]);
    fetch(TRACKS[i].src).then(function(r){if(!r.ok)throw Error('audio');return r.text();}).then(function(raw){
      var bin=atob(raw.trim()),bytes=new Uint8Array(bin.length);
      for(var k=0;k<bin.length;k++)bytes[k]=bin.charCodeAt(k);
      if(audioBlobUrl)URL.revokeObjectURL(audioBlobUrl);
      audioBlobUrl=URL.createObjectURL(new Blob([bytes],{type:'audio/webm'}));
      audio.src=audioBlobUrl;audio.load();
      if(autoplay){var p=audio.play();if(p&&p.catch)p.catch(audioUnavailable);}
    }).catch(audioUnavailable);
  }
  function audioUnavailable(){
    mount.querySelector('.story-audio-note').textContent='El navegador no pudo cargar la grabación. El recorrido y la transcripción permanecen disponibles.';
    play.setAttribute('aria-label','Audio no disponible');
  }
  function clearWords(){mount.querySelectorAll('.story-word.is-current,.story-word.is-past').forEach(function(w){w.classList.remove('is-current','is-past');});}
  function update(){
    var d=audio.duration||durations[currentTrack]||0,t=audio.currentTime||0,p=d?t/d:0;
    progress.style.width=(p*100)+'%';time.textContent=fmt(t)+' / '+fmt(d);
    wave.setAttribute('aria-valuenow',String(Math.round(p*100)));
    var map=wordMap[currentTrack],hit=null;
    for(var i=0;i<map.length;i++){if(t>=map[i].start)hit=map[i];else break;}
    if(hit){
      var stop=stops[hit.scene];
      stops.forEach(function(s,j){s.classList.toggle('is-active',j===hit.scene);});
      mount.querySelectorAll('.story-word.is-current').forEach(function(w){w.classList.remove('is-current');});
      var ws=stop.querySelectorAll('.story-word');
      for(var j=0;j<ws.length;j++){ws[j].classList.toggle('is-current',j===hit.word);ws[j].classList.toggle('is-past',j<hit.word);}
      if(lastScene!==hit.scene){lastScene=hit.scene;now.textContent=STORY[hit.scene].title;if(autoFollow&&!audio.paused&&Date.now()-userScrollAt>4500)stop.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth',block:'center'});}
    }
  }
  function toggle(){
    if(!audio.src||audio.error){audioUnavailable();return;}
    if(audio.paused){var p=audio.play();if(p&&p.catch)p.catch(audioUnavailable);}else audio.pause();
  }
  play.addEventListener('click',toggle);
  audio.addEventListener('play',function(){play.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>';play.setAttribute('aria-label','Pausar');});
  audio.addEventListener('pause',function(){play.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4v16l13-8z"/></svg>';play.setAttribute('aria-label','Reproducir');});
  audio.addEventListener('loadedmetadata',function(){durations[currentTrack]=audio.duration;if(!hasExactTiming)buildMap();update();});
  audio.addEventListener('timeupdate',update);
  audio.addEventListener('ended',function(){play.focus();});
  audio.addEventListener('error',audioUnavailable);
  trackButtons.forEach(function(b){b.addEventListener('click',function(){setTrack(+b.dataset.track,true);});});
  wave.addEventListener('click',function(e){if(!audio.duration)return;var r=wave.getBoundingClientRect();audio.currentTime=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*audio.duration;update();});
  wave.addEventListener('keydown',function(e){if(!audio.duration)return;if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();audio.currentTime=Math.max(0,Math.min(audio.duration,audio.currentTime+(e.key==='ArrowRight'?5:-5)));update();}});
  stops.forEach(function(stop,i){
    stop.querySelectorAll('.story-word').forEach(function(w){w.addEventListener('click',function(){var item=wordMap[STORY[i].track].find(function(x){return x.scene===i&&x.word===+w.dataset.word;});if(!item)return;if(currentTrack!==STORY[i].track)setTrack(STORY[i].track,false);audio.currentTime=item.start;audio.play().catch(audioUnavailable);});});
  });
  window.addEventListener('wheel',function(){userScrollAt=Date.now();},{passive:true});
  window.addEventListener('touchmove',function(){userScrollAt=Date.now();},{passive:true});
  var observer=new IntersectionObserver(function(entries){if(audio.paused){entries.forEach(function(e){if(e.isIntersecting&&e.intersectionRatio>.42){stops.forEach(function(s){s.classList.toggle('is-active',s===e.target);});}});}},{threshold:[.42,.65]});
  stops.forEach(function(s){observer.observe(s);});
  var chromeObserver=new IntersectionObserver(function(entries){
    document.body.classList.toggle('story-reading',entries.some(function(e){return e.isIntersecting;}));
  },{threshold:.02});
  chromeObserver.observe(mount);
  setTrack(0,false);
  fetch('assets/data/story-timing.json').then(function(r){if(!r.ok)throw Error('timing');return r.json();}).then(function(d){
    if(Array.isArray(d.words)&&d.words.length){
      wordMap[0]=d.words;
      hasExactTiming=true;
      durations[0]=d.duration||durations[0];
      mount.dataset.timing='ready';
      update();
    }
  }).catch(function(){/* La distribución proporcional mantiene el componente legible fuera del servidor. */});
})();